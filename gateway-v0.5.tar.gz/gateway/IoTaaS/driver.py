#!/usr/bin/env python

from subprocess import call
from time import sleep
from interface.interfaceI2C import InterfaceI2C
from threading import Thread


from logger import Logger,ErrorLog,OutLog
import logging
import sys
import os


from urllib import urlretrieve

class CardMonitorThread(Thread):
    def __init__(self, i2c):
        Thread.__init__(self)
        self.i2c = i2c

    def run(self):
        cpt = 0
        while True:
            if not self.i2c.detectDevice():
                cpt +=1
                if(cpt == 5):
                    option = "restart"
                    print "card not detected, restart the driver"
                    call(['/etc/init.d/launch_driver.sh',str(option)])
            else:
                sleep(2)

log = Logger("/var/log/IoTaas.log", logging.INFO)
sys.stderr = ErrorLog(log)
sys.stdout = OutLog(log)


# wait for card
i2c = InterfaceI2C(1, 0x50)
while(not i2c.detectDevice()):
    print "no card detcted"
    sleep(1)

# card plugged ==> read package identifier
ID = i2c.read(0,2)
print "card pluged, withe ID: " + str(ID)

thm = CardMonitorThread(i2c)
thm.start()

if(os.path.isdir("/usr/local/lib/python2.7/dist-packages/IoTaas_Devices_API-0.1-py2.7.egg") == False):
    # download and install the package with ID
    print "download package with ID :", ID
    urlretrieve ("https://raw.githubusercontent.com/Oussalvatore/download_test/master/Devices-API.tar.gz", "/tmp/Devices-API.tar.gz")
    print "extract and install Device API"
    call(['/usr/local/bin/IoTaas_Driver/extract_and_install.sh'])
    if (os.path.isdir("/usr/local/lib/python2.7/dist-packages/IoTaas_Devices_API-0.1-py2.7.egg") == False):
        print "Device-API installation failed:/"
        sys.exit(0)


from program.program import Program
start_program = Program(0, queue_in="config_in", queue_out="config_out")

print ("waiting for request =D ")


