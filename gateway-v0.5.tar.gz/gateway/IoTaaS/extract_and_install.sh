#!/usr/bin/env bash
#extract the installation folder
tar -xzf /tmp/Devices-API.tar.gz -C /tmp/

#clean tar file
rm /tmp/Devices-API.tar.gz

#install devices API
/tmp/Devices-API/install_devices.sh

#clean installation folder
rm -R /tmp/Devices-API/

