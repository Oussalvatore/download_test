#!/bin/bash

echo "update package "
apt-get update
#erify and install python
echo "export LC_ALL=C" >> ~/.bashrc
py=`which python`
if [[ $py = "/usr/bin/python" ]]
then
    echo "python is already installed, good :)"
else

    echo "installing python .............."
    apt-get -y install python
    py=`which python`
    if [[ $py != "/usr/bin/python" ]]
    then
        echo "python installation failed, stop install process"
        exit 1
     else
        echo "python was successfully installed "
      fi
fi

pip=`which pip`
if [[ $pip = "/usr/bin/pip" ]]
then
    echo "pip is already installed, good :)"
else
    echo "installing pip .............."
    apt-get -y install python-pip
    pip=`which pip`
    if [[ $pip != "/usr/bin/pip" ]]
    then
        echo "pip installation failed, stop install process"
        exit 1
     else
        echo "pip was successfully installed "
      fi
fi

#verify and configure i2c tools
if grep -Fxq "device_tree_param=i2c_arm=on" /boot/config.txt
then
    echo "i2c enabled"
else
    echo "enable i2c from /boot/config.txt"
    echo "device_tree_param=i2c_arm=on" >> /boot/config.txt
fi

if grep -Fxq "bcm2708.vc_i2c_override=1" /boot/cmdline.txt
then
    echo "i2c commande line enabled"
else
    echo "enable i2c commande line from /boot/cmdline.txt"
    echo "bcm2708.vc_i2c_override=1" >> /boot/cmdline.txt
fi

if ! grep -Fxq "i2c-bcm2708" /etc/modules-load.d/modules.conf
then
    echo "write i2c-bcm2708 to etc/modules-load.d/modules.conf "
    echo "i2c-bcm2708" >> /etc/modules-load.d/modules.conf
fi

if ! grep -Fxq "i2c-dev" /etc/modules-load.d/modules.conf
then
    echo "write i2c-dev to etc/modules-load.d/modules.conf "
    echo "i2c-dev" >> /etc/modules-load.d/modules.conf
fi

i2c=`which i2cdetect`
if [[ $i2c = "/usr/sbin/i2cdetect" ]]
then
    echo "i2c-tools is already installed, good :)"
else
    echo "installing i2c-tools .............."
    apt-get -y install i2c-tools
    apt-get -y install python-smbus
    i2c=`which i2cdetect`
    if [[ $i2c != "/usr/sbin/i2cdetect" ]]
    then
        echo "i2c-tools installation failed, stop install process"
        exit 1
     else
        echo "i2c-tools was successfully installed :) "
      fi
fi

# install pika for rabbitMQ
echo "installing pika .............."
apt-get install python-pika


# install the driver (launch driver.py)
echo "creat driver directory at /usr/local/bin/IoTaas_Driver"
mkdir /usr/local/bin/IoTaas_Driver

echo "copy installation file to driver directory"
cp -a ./. /usr/local/bin/IoTaas_Driver

echo "copy launch script to /etc/init.d"
cp launch_driver.sh /etc/init.d
update-rc.d launch_driver.sh defaults

echo "restart now .................."
reboot


