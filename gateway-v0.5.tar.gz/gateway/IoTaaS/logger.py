import logging
import logging.handlers
import argparse


class Logger:
    def __init__(self,logFileName,logLevel):

        self.logFileName = logFileName
        self.logLevel = logLevel

        self.formatter = logging.Formatter('%(asctime)s %(levelname)-8s %(message)s')

        self.handler = logging.handlers.TimedRotatingFileHandler(self.logFileName, when="midnight", backupCount=3)
        self.handler.setFormatter(self.formatter)

        self.logger = logging.getLogger(__name__)
        self.logger.setLevel(self.logLevel)
        self.logger.addHandler(self.handler)


class ErrorLog(object):
    def __init__(self,logger):
        self.logger = logger

    def write(self, message):
        if message.rstrip() != "":
            self.logger.logger.log(logging.ERROR, message.rstrip())

class OutLog(object):
    def __init__(self,logger):
        self.logger = logger

    def write(self, message):
        if message.rstrip() != "":
            self.logger.logger.log(logging.INFO, message.rstrip())