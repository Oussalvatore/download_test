#!/usr/bin/python
# from interface.InterfaceI2C import InterfaceI2C
from wrapper.wrapper import Wrapper  # actually downloaded from source
from time import sleep
# from threading import  Thread
# import json
import threading
from wrapper import events
import pika
import cPickle as Pickle
credentials = pika.PlainCredentials('iotaas', 'iotaas123456')
parameters = pika.ConnectionParameters('195.148.125.17',
                                       5672,
                                       '/',
                                       credentials)


class DelayedThreadSensing(threading.Thread):
    def __init__(self, wrapper1, targeted_sensors, delay, parameters_param=parameters):
        threading.Thread.__init__(self)
        self.daemon = True
        self.__targeted_sensors = targeted_sensors
        self.__delay = delay
        self.__wrapper = wrapper1
        self.__connection = pika.BlockingConnection(parameters_param)
        self.__channel = self.__connection.channel()

    def run(self):
        for i in self.__targeted_sensors:
            self.__channel.queue_declare(queue=i+"")
        while True:
            for i in self.__targeted_sensors:
                data = self.__wrapper.sense_from(i)
                to_write = Pickle.dumps(data)
                self.__channel.basic_publish(exchange="",
                                             routing_key=i+"",
                                             body=to_write)
            sleep(self.__delay)


class DelayedThreadActing(threading.Thread):
    def __init__(self, wrapper1, targeted_actuators, delay):
        threading.Thread.__init__(self)
        self.__targeted_actuators = targeted_actuators
        self.__delay = delay
        self.__wrapper = wrapper1
        self.daemon = True

    def run(self):
        while True:
            for i in self.__targeted_actuators:
                self.__wrapper.act_on(i)
                # print i, data (not necessary)
            sleep(self.__delay)


class EventWaitingThread(threading.Thread):
    def __init__(self, wrapper1, targeted_sensor, events1, parameters_param=parameters):
        threading.Thread.__init__(self)
        self.daemon = True
        self.__targeted_sensor = targeted_sensor
        self.__wrapper = wrapper1
        self.__events = events1
        self.__connection = pika.BlockingConnection(parameters_param)
        self.__channel = self.__connection.channel()

    def run(self):
        self.__channel.queue_declare(queue=self.__targeted_sensor)
        while True:
            data = self.__wrapper.trigger_on(self.__targeted_sensor, self.__events)
            for key in data.iterkeys():
                to_write = "xxx IMPOSSIBLE. HOW DID THAT HAPPENED. xxx"
                if type(data[key]) == list:
                    operation = ""
                    if data[key][1] == events.GREATER_THAN:
                        operation = "Greater than:"
                    elif data[key][1] == events.LOWER_THAN:
                        operation = "Lower than:"
                    elif data[key][1] == events.EQUAL:
                        operation = "Equal:"
                    elif data[key][1] == events.EQUAL_MARGIN:
                        operation = "Equal margin:"
                    elif data[key][1] == events.DIFFERENCE_OF:
                        operation = "Jumped from:"
                    to_write = "Event from :", self.__targeted_sensor, "sensed value:", data[key][0], operation,\
                               data[key][2]
                elif type(data[key]) == dict:
                    for i in data[key].iterkeys():
                        operation = ""
                        if data[key][i][1] == events.GREATER_THAN:
                            operation = "Greater than:"
                        elif data[key][i][1] == events.LOWER_THAN:
                            operation = "Lower than:"
                        elif data[key][i][1] == events.EQUAL:
                            operation = "Equal:"
                        elif data[key][i][1] == events.EQUAL_MARGIN:
                            operation = "Equal margin:"
                        elif data[key][i][1] == events.DIFFERENCE_OF:
                            operation = "Jumped from:"
                        to_write = "Event from :", self.__targeted_sensor, "the", key, \
                                   "sensed value:", data[key][i][0], operation, data[key][i][2]

                self.__channel.basic_publish(exchange="",
                                             routing_key=self.__targeted_sensor+"",
                                             body=to_write)


class QueryHandlerThread(threading.Thread):
    def __init__(self, wrapper1, parameters_param=parameters, queue_in="queries_in", queue_out="queries_out"):
        threading.Thread.__init__(self)
        self.daemon = True
        self.__wrapper = wrapper1
        self.__connection = pika.BlockingConnection(parameters_param)
        self.__channel = self.__connection.channel()
        self.__queue_in = queue_in
        self.__queue_out = queue_out

    def run(self):
        self.__channel.queue_declare(queue=self.__queue_in)
        self.__channel.queue_declare(queue=self.__queue_out)
        while True:
            method, properties, data = self.__channel.basic_get(queue=self.__queue_in, no_ack=True)
            if method:
                queries = data.split('\$')
                for str_query in queries:
                    query = Pickle.loads(str_query)
                    if type(query) == list:
                        for asked_sensor in query:
                            to_return = self.__wrapper.sense_from(asked_sensor)
                            to_write = Pickle.dumps(to_return)
                            self.__channel.basic_publish(exchange="",
                                                         routing_key=self.__queue_out,
                                                         body=to_write)


class Program:
    def __init__(self, ident, config=None, parameters_param=parameters, queue_in="in", queue_out="out"):
        # Download the jacket files here
        self.__wrapper = Wrapper()
        self.__sensors = self.__wrapper.get_sensors()
        self.__actuators = self.__wrapper.get_actuators()
        self.__id = ident
        self.__connection = pika.BlockingConnection(parameters_param)
        self.__channel = self.__connection.channel()
        self.__queue_in = queue_in
        self.__queue_out = queue_out
        self.__cpt = 0
        if config is not None:
            self.__cpt += 1
            self.__apply_config(config)
        self.__main()

    def __init_delays_sensing_threads(self, delays_sensing):
        delays_sensing_threads = []
        for key, value in delays_sensing.iteritems():
            thd = DelayedThreadSensing(self.__wrapper, value, key)
            delays_sensing_threads.append(thd)
            thd.start()
        return delays_sensing_threads

    def __init_delays_acting_threads(self, delays_acting):
        delays_acting_threads = []
        for key, value in delays_acting.iteritems():
            thd = DelayedThreadActing(self.__wrapper, value, key)
            delays_acting_threads.append(thd)
            thd.start()
        return delays_acting_threads

    def __init_on_event_sensing_threads(self, on_event_sensing):
        on_event_sensing_threads = []
        for key, value in on_event_sensing.iteritems():
            thd = EventWaitingThread(self.__wrapper, key, value)
            on_event_sensing_threads.append(thd)
            thd.start()
        return on_event_sensing_threads

    def __apply_config(self, config):
        delays_sensing = config["delays_sensing"]
        delays_acting = config["delays_acting"]
        on_event_sensing = config["on_event_sensing"]

        self.__init_delays_sensing_threads(delays_sensing)
        self.__init_delays_acting_threads(delays_acting)
        self.__init_on_event_sensing_threads(on_event_sensing)

        self.__channel.basic_publish(exchange="",
                                     routing_key=self.__queue_out,
                                     body="Configuration well applied.")

    def __main(self):
        if self.__cpt == 0:
            to_write = Pickle.dumps(self.__sensors)
            self.__channel.queue_declare(queue=self.__queue_in)
            self.__channel.queue_declare(queue=self.__queue_out)
            self.__channel.basic_publish(exchange="",
                                         routing_key=self.__queue_out,
                                         body=to_write)

        queries_thd = QueryHandlerThread(self.__wrapper, queue_in="queries_in", queue_out="queries_out")
        queries_thd.start()

        while True:
            method, properties, data = self.__channel.basic_get(queue=self.__queue_in, no_ack=True)
            if method and self.__cpt == 0:
                all_received_configs = data.split('\$')
                str_config = all_received_configs[len(all_received_configs) - 1]  # get the last received config.

                config = Pickle.loads(str_config)

                if self.__cpt == 0:
                    self.__apply_config(config)
                else:
                    program = Program(self.__id, config=config, parameters_param=parameters,
                                      queue_in=self.__queue_in, queue_out=self.__queue_out)
                    break

        # Begin config Example
        # delays_sensing = {2: ["temp_hum", "pir"]}  # , 5: ["camera"]}
        # delays_acting = {5: ["led1"]}
        # on_event_sensing = {"temp_hum": {"Humidity": [events.Event(events.DIFFERENCE_OF, difference=5),
        #                                               events.Event(events.EQUAL_MARGIN, value=20, margin=5)],
        #                                  "Temperature": [events.Event(events.DIFFERENCE_OF, difference=5),
        #                                                  events.Event(events.EQUAL_MARGIN, value=20, margin=5)]},
        #                     "pir": [events.Event(events.EQUAL, value=True)]}
        # End of config example
