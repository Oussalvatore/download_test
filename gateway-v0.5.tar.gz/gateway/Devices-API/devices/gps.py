class GPS:
    def __init__(self,i2c):
        self.i2c = i2c