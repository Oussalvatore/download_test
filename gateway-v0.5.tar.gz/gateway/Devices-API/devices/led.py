from interfaces.boardGpio import BoardGpio
from interfaces.interfaceGPIO import InterfaceGPIO


class Led:
    def __init__(self, which_board, physical_pin_number):
        pin = BoardGpio(which_board=which_board, physical_pin_number=physical_pin_number)
        self.__gpio = InterfaceGPIO(out=physical_pin_number)
        self.__last_state = 0

    def act(self):
        self.__last_state = (self.__last_state + 1) % 2
        self.__gpio.write(self.__last_state)
        return True

