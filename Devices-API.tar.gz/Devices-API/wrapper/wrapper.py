from threading import Lock

import devices.led as led
import devices.motion as motion
import devices.tempHumDHT as tempHumDHT
import devices.ttlCamera as ttlCamera
from interfaces.boardGpio import Pi_2_B


class Wrapper:
    def __init__(self):
        # If needed install dependencies
        self.__sensors = {"temp_hum": {"Description": "Temperature and Humidity sensor.",
                                       "Object": tempHumDHT.TempHumDHT(tempHumDHT.DHT22, 16)},
                          "camera": {"Description": "Video Camera",
                                     "Object": ttlCamera.TtlCamera(port="/dev/ttyAMA0", baud=38400, timeout=0.3,
                                                                   serial_number=0)},
                          "pir": {"Description": "Motion sensor.", "Object": motion.Motion(13)}
                          }
        self.__actuators = {"led1": {"Description": "It's just a led.", "Object": led.Led(which_board=Pi_2_B,
                                                                                          physical_pin_number=26)}}

        # Don't modify below (BEGIN).
        self.__sensors_locks = {}
        for i in self.__sensors.iterkeys():
            self.__sensors_locks[i] = Lock()

        self.__actuators_locks = {}
        for i in self.__actuators.iterkeys():
            self.__actuators_locks[i] = Lock()
            # Don't modify above (END).

    # must be defined in any wrapper class exactly as below (do never change the code below (please :p)).
    def get_sensors(self):
        return self.__sensors

    # must be defined in any wrapper class exactly as below (do never change the code below (please :p)).
    def get_actuators(self):
        return self.__actuators

    # must be defined in any wrapper class exactly as below (do never change the code below (please :p)).
    def sense_from(self, label):
        self.__sensors_locks[label].acquire()
        data = self.__sensors[label]["Object"].sense()
        self.__sensors_locks[label].release()
        return data

    # must be defined in any wrapper class exactly as below (do never change the code below (please :p)).
    def trigger_on(self, label, events):
        if type(events) == list:
            for event in events:
                self.__sensors[label]["Object"].add_event(event, key=None)
        elif type(events) == dict:
            for key, value in events.iteritems():
                for event in value:
                    self.__sensors[label]["Object"].add_event(event=event, key=key)
        else:
            return None
        lock = self.__sensors_locks[label]
        data = self.__sensors[label]["Object"].trigger_on_event(lock=lock)
        return data

    # must be defined in any wrapper class exactly as below (do never change the code below (please :p)).
    def act_on(self, label):
        self.__actuators_locks[label].acquire()
        data = self.__actuators[label]["Object"].act()
        self.__actuators_locks[label].release()
        return data
