GREATER_THAN = 0
LOWER_THAN = 1
EQUAL = 2
EQUAL_MARGIN = 3
DIFFERENCE_OF = 4


class Event:
    def __init__(self, operator, value=None, difference=None, margin=None):
        self.__operation = operator
        self.__value_to_compare = value
        self.__difference = difference
        self.__margin = margin
        self.__operators = {GREATER_THAN: self.__greater_than, LOWER_THAN: self.__lower_than,
                            EQUAL: self.__equal, EQUAL_MARGIN: self.__equal_margin,
                            DIFFERENCE_OF: self.__difference_of}

    def get_operator(self):
        return self.__operation

    def get_value_to_compare(self):
        return self.__value_to_compare

    def __greater_than(self, sensed_value):
        return sensed_value > self.__value_to_compare

    def __lower_than(self, sensed_value):
        return sensed_value < self.__value_to_compare

    def __equal(self, sensed_value):
        return sensed_value == self.__value_to_compare

    def __equal_margin(self, sensed_value):
        return (sensed_value <= self.__value_to_compare + self.__margin) and \
               (sensed_value >= self.__value_to_compare - self.__margin)

    def __difference_of(self, sensed_value):
        if self.__value_to_compare is None:
            self.__value_to_compare = sensed_value
            return False
        to_return = (sensed_value >= (self.__value_to_compare + self.__difference)) or \
                    (sensed_value <= (self.__value_to_compare - self.__difference))
        self.__value_to_compare = sensed_value
        return to_return

    def event_happened(self, sensed_value):
        return self.__operators[self.__operation](sensed_value)

