import RPi.GPIO as GPIO


class InterfaceGPIO:
    def __init__(self, out=None, inpt=None):
        self.__output = out  # output pin list
        self.__input = inpt  # input pin list

        GPIO.setwarnings(False)
        GPIO.setmode(GPIO.BOARD)  # set up BOARD GPIO numbering
        # Set up output pin
        if self.__output is not None:
            GPIO.setup(self.__output, GPIO.OUT)
        # Set up input pin
        if self.__input is not None:
            GPIO.setup(self.__input, GPIO.IN, pull_up_down=GPIO.PUD_DOWN)

    def clean_up(self):
        GPIO.cleanup()

    def read(self):
        if self.__input is not None:
            return GPIO.input(self.__input)  # return false or true
        else:
            print "no such input pin"
            return None

    def write(self, level):
        if self.__output is not None:
            GPIO.output(self.__output, level)  # level must be 0 or 1
        else:
            print "no such output pin"
