class InterfaceSPI:
    def __init__(self,mosi,miso,sclk):
        self.mosi = mosi
        self.miso =miso
        self.sclk =sclk
