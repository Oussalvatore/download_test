phys_gpio_dictionary_pi_3 = {
    11: 0, 12: 1, 13: 2, 15: 3, 16: 4, 18: 5, 22: 6, 7: 7, 3: 8, 5: 9, 24: 10, 26: 11, 19: 12, 21: 13,
    23: 14, 8: 15, 10: 16, 29: 21, 31: 22, 33: 23, 35: 24, 37: 25, 32: 26, 36: 27, 38: 28, 40: 29
}

phys_gpio_dictionary_pi_2_B = {
    3: 2, 5: 3, 7: 4, 8: 14, 10: 15, 11: 17, 12: 18, 13: 27, 15: 22, 16: 23, 18: 24, 19: 10, 21: 9,
    22: 25, 23: 11, 24: 8, 26: 7, 29: 5, 31: 6, 32: 12, 33: 13, 35: 19, 36: 16, 37: 26, 38: 20, 40: 21
}

Pi_2_B = 0
Pi_3 = 1
Pi_2 = 2
Pi_1 = 3
Odroid_C2 = 4
# To Extend as much as possible

# TODO : Complete The dictionary below.
phys_gpio_dictionary = {Pi_2_B: phys_gpio_dictionary_pi_2_B, Pi_3: phys_gpio_dictionary_pi_3}


class BoardGpio:
    def __init__(self, which_board, physical_pin_number):
        if not phys_gpio_dictionary.keys().__contains__(which_board):
            raise Exception("Invalid board number selection (None related board)")
        if not phys_gpio_dictionary[which_board].__contains__(physical_pin_number):
            raise Exception("Invalid physical pin number (None related GPIO in the selected board)")

        self.physical_pin_number = physical_pin_number
        self.board = which_board
        self.gpio_number = phys_gpio_dictionary[which_board][physical_pin_number]

    def get_physical_pin_number(self):
        return self.physical_pin_number

    def get_gpio_number(self):
        return self.gpio_number
