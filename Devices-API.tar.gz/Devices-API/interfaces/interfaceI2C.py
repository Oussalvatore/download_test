import smbus


class InterfaceI2C:
    def __init__(self, busNum, deviceAddress):
        self.bus = smbus.SMBus(busNum)
        self.deviceAddress = deviceAddress

    def getDeviceAddress(self):
        return self.deviceAddress

    def setDeviceAddress(self, value):
        self.deviceAddress = value

    def detectDevice(self):
        try:
            self.bus.read_byte(self.deviceAddress)
            return True
        except IOError:
            return False

    def read(self, offset, dataSize):
        if dataSize == 1:
            return self.bus.read_byte_data(self.deviceAddress, offset)
        elif dataSize == 2:
            return self.bus.read_word_data(self.deviceAddress, offset)
        elif dataSize == 32:
            return self.bus.read_i2c_block_data(self.deviceAddress, offset)
        else:
            raise Exception('invalid data size, possible values : 1,2 or 32')

    def write(self, offset, data):
        if isinstance(data, int):
            self.bus.write_byte_data(self.deviceAddress, offset, data)
        elif isinstance(data, list):
            if len(data) > 32:
                raise Exception('data size too large : max 32 bytes')
            else:
                self.bus.write_i2c_block_data(self.deviceAddress, offset, data)
        else:
            raise Exception('data must be in list or int format')
