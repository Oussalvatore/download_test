import serial
from time import sleep


class InterfaceUART:
    def __init__(self, port, baud, timeout):
        try:
            self.serialBus = serial.Serial(port=port, baudrate=baud, timeout=timeout)
        except Exception as ex:
            print ex

    def get_serial_bus(self):
        return self.serialBus

    def execute_command(self, command):
        to_write = ''.join(map(chr, command))
        self.serialBus.write(to_write)
        sleep(0.04)

    def get_command_reply(self, nbr_bytes_to_read):
        return self.serialBus.read(nbr_bytes_to_read)

    def check_command_execution(self, command_reply):
        nbr_bytes_to_check = len(command_reply)
        char_buf = self.serialBus.read(nbr_bytes_to_check)
        list_buf = list(char_buf)
        bytes_to_check = map(ord, list_buf)
        for i in range(0, nbr_bytes_to_check):
            if bytes_to_check[i] != command_reply[i]:
                return False
        return True