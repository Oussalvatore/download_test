class Water:
    def __init__(self,spi):
        self.spi = spi