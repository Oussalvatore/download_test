from time import sleep
from interfaces.interfaceGPIO import InterfaceGPIO


class Motion:
    def __init__(self, pin_number):
        # BEGIN: must be declared in any sensor interface "list if the return of sense() is a single value
        # dictionary if the return of sense() is a tuple.
        self.__events = []
        # END: must be declared in any sensor interface.
        self.gpio = InterfaceGPIO(None, pin_number)

    def sense(self):
        for i in range(0, 30):
            if self.gpio.read():
                return True
        return False

    # BEGIN MUST : Define event happened parameter.
    def add_event(self, event, key=None):
        self.__events.append(event)

    def trigger_on_event(self, lock):
        while True and len(self.__events) > 0:
            lock.acquire()
            to_return = {}
            cpt = 0
            for event in self.__events:
                data = self.sense()
                if event.event_happened(data):
                    to_return[cpt] = []
                    to_return[cpt].append(data)
                    to_return[cpt].append(event.get_operator())
                    to_return[cpt].append(event.get_value_to_compare())
                    cpt += 1
            if len(to_return) > 0:
                lock.release()
                sleep(3)
                return to_return
            lock.release()
            sleep(3)
    # END MUST.

