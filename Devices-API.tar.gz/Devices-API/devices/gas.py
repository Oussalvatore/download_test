class Gas:
    def __init__(self,gpio):
        self.gpio = gpio