from time import sleep
import interfaces.boardGpio as boardGpio
import Adafruit_DHT as Dht

DHT22 = 0
DHT11 = 1
AM2301 = 2

sensors = {0: Dht.DHT22, 1: Dht.DHT11, 2: Dht.AM2302}


class TempHumDHT:
    def __init__(self, sensor, physical_pin_number):
        # BEGIN: must be declared in any sensor interface "list if the return of sense() is a single value
        # dictionary if the return of sense() is a tuple.
        self.__events = {}
        # END MUST: be declared in any sensor interface.
        self.sensor = sensors[sensor]
        self.pin = boardGpio.BoardGpio(which_board=boardGpio.Pi_2_B, physical_pin_number=physical_pin_number)

    # MUST be declared as "sense(self)".
    def sense(self):
        cpt = 0
        while cpt < 3:
            try:
                humidity, temperature = Dht.read_retry(self.sensor, self.pin.get_gpio_number())
                if humidity is not None and temperature is not None:
                    return {"Humidity": humidity, "Temperature": temperature}
                    # print('Temp={0:0.1f}*C  Humidity={1:0.1f}%'.format(temperature, humidity))
                else:
                    cpt += 1
            except Exception as ex:
                print ex
        print "Shit."
        raise Exception("Unable to sens any data data")

    # BEGIN MUST : Define event happened parameter.
    def add_event(self, event, key=None):
        self.__events[key] = []
        self.__events[key].append(event)

    def trigger_on_event(self, lock):
        while True and len(self.__events.keys()) > 0:
            lock.acquire()
            to_return = {}
            for key in self.__events.keys():
                cpt = 0
                to_return[key] = {}
                for event in self.__events[key]:
                    data = self.sense()
                    if event.event_happened(data[key]):
                        to_return[key][cpt] = []
                        to_return[key][cpt].append(data[key])
                        to_return[key][cpt].append(event.get_operator())
                        to_return[key][cpt].append(event.get_value_to_compare())
                        cpt += 1
            if len(to_return.keys()) > 0:
                lock.release()
                return to_return
            lock.release()
            sleep(0.5)
    # END MUST.
