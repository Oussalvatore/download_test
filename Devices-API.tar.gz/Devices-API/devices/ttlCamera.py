from time import sleep
from interfaces.interfaceUART import InterfaceUART


class TtlCamera:
    def __init__(self, port, baud, timeout, serial_number):
        # BEGIN: must be declared in any sensor interface "list if the return of sense() is a single value
        # dictionary if the return of sense() is a tuple.
        self.__events = []
        # END: must be declared in any sensor interface.
        self.interface = InterfaceUART(port=port, baud=baud, timeout=timeout)
        self.MH_0 = 0x00
        self.ML_0 = 0x00
        self.KH_0 = 0x00
        self.KL_0 = 0x00
        self.MH_1 = 0x00
        self.ML_1 = 0x00
        self.KH_1 = 0x00
        self.KL_1 = 0x00
        self.serialNumber = serial_number
        self.resetCommand = [0x56, serial_number, 0x26, 0x00]
        self.takePhotoCommand = [0x56, serial_number, 0x36, 0x01, 0X00]
        self.stopTakingPhotoCommand = [0x56, serial_number, 0x36, 0x01, 0X03]
        self.getBuffLenCommand = [0x56, serial_number, 0x34, 0x01, 0X00]
        self.resetCommandReply = [0x76, serial_number, 0x26, 0x00]
        self.takePhotoCommandReply = [0x76, serial_number, 0x36, 0x00, 0X00]
        self.stopTakingPhotoCommandReply = [0x76, serial_number, 0x36, 0x00, 0x00]
        self.getBuffLenCommandReply = [0x76, serial_number, 0x34, 0x00, 0x04]
        self.buffLenBytesNbr = 4
        self.readPhotoCommand = [0x56, serial_number, 0x32, 0x0c, 0x00, 0x0a, self.MH_0, self.ML_0, self.MH_1,
                                 self.ML_1, self.KH_0, self.KL_0, self.KH_1, self.KL_1, 0x00, 0x0a]
        self.readPhotoHeaderSize = 5
        self.readPhotoCommandReply = [0x76, serial_number, 0x32, 0x00, 0x00]

    def reset(self):
        try:
            self.interface.execute_command(self.resetCommand)
            return self.interface.check_command_execution(self.resetCommandReply)
        except Exception as ex:
            print ex.message
            return False

    def snap_image(self):
        try:
            self.interface.execute_command(self.takePhotoCommand)
            return self.interface.check_command_execution(self.takePhotoCommandReply)
        except Exception:
            return False

    def stop_taking_images(self):
        try:
            self.interface.execute_command(self.stopTakingPhotoCommand)
            return self.interface.check_command_execution(self.stopTakingPhotoCommandReply)
        except Exception:
            return False

    def get_image_size(self):
        try:
            self.interface.execute_command(self.getBuffLenCommand)
            if self.interface.check_command_execution(self.getBuffLenCommandReply):
                str_result = self.interface.get_command_reply(nbr_bytes_to_read=self.buffLenBytesNbr)
                result = list(str_result)
                img_size = ord(result[0])
                img_size <<= 8
                img_size += ord(result[1])
                img_size <<= 8
                img_size += ord(result[2])
                img_size <<= 8
                img_size += ord(result[3])
                return img_size
        except:
            pass
        return -1

    def get_image(self, img_size, preferred_chunk):
        if (preferred_chunk % 8) != 0:
            raise Exception("The chunk must be multiple of 8.")
        elif preferred_chunk > img_size and img_size % 8 != 0:
            raise Exception("Segmentation Error if continue.")
        adr = 0
        cpt = 0
        image = []
        while adr < img_size:
            if cpt >= 3:
                raise Exception("Exception while trying to read image data.")
            cpt += 1
            sleep(0.04)

            chunk = min(img_size - adr, preferred_chunk)
            if chunk % 8 != 0:
                chunk += 8 - (chunk % 8)

            x = chunk
            self.KH_0 = int(x / 0x1000000)
            x %= 0x1000000
            self.KL_0 = int(x / 0x10000)
            x %= 0x10000
            self.KH_1 = int(x / 0x100)
            x %= 0x100
            self.KL_1 = x

            self.readPhotoCommand[6] = self.MH_0
            self.readPhotoCommand[7] = self.ML_0
            self.readPhotoCommand[8] = self.MH_1
            self.readPhotoCommand[9] = self.ML_1
            self.readPhotoCommand[10] = self.KH_0
            self.readPhotoCommand[11] = self.KL_0
            self.readPhotoCommand[12] = self.KH_1
            self.readPhotoCommand[13] = self.KL_1

            self.interface.execute_command(self.readPhotoCommand)
            size_to_read = self.readPhotoHeaderSize + chunk + self.readPhotoHeaderSize
            str_result = self.interface.get_command_reply(size_to_read)
            result = list(str_result)
            if len(result) != size_to_read:
                continue
            for i in range(0, len(self.readPhotoCommandReply)):
                if result[i] != self.readPhotoCommandReply[i] or result[size_to_read - 5 + i] != \
                        self.readPhotoCommandReply[i]:
                    raise Exception("Error while reading the image data.")

            image += result[self.readPhotoHeaderSize:chunk + self.readPhotoHeaderSize]

            adr += chunk

            x = adr
            self.MH_0 = int(x / 0x1000000)
            x %= 0x1000000
            self.ML_0 = int(x / 0x10000)
            x %= 0x10000
            self.MH_1 = int(x / 0x100)
            x %= 0x100
            self.ML_1 = x

        return image

    def photograph(self):
        #    cpt = 0
        #    while not self.reset():
        #        cpt += 1
        #        if cpt >= 3:
        #            raise Exception("Error trying to init the camera.")
        #    sleep(3)

        cpt = 0
        cpt0 = 0
        while not self.snap_image():
            cpt0 += 1
            print ".....", cpt, "....."
            if cpt0 >= 3:
                cpt0 = 0
                cpt += 1
                self.reset()
                sleep(2)
                continue
            if cpt >= 3:
                raise Exception("Error trying to snap the image.")

        cpt = 0
        img_size = -1
        while img_size == -1:
            img_size = self.get_image_size()
            if cpt >= 3 and img_size == -1:
                raise Exception("Error trying to get the image size.")
            cpt += 1

        if img_size % 8 == 0:
            chunk = img_size
        else:
            chunk = img_size - (img_size % 8)
        cpt = 0
        image = []
        while cpt < 3:
            cpt += 1
            try:
                image = self.get_image(img_size, chunk)
            except Exception as ex:
                print ex.message

        return image

    # MUST be declared.
    def sense(self):
        # selek berk hadi camera instable bezaf.
        self.reset()
        data = self.photograph()
        self.stop_taking_images()
        return data

    # BEGIN MUST : Define event happened parameter.
    def add_event(self, event, key=None):
        self.__events.append(event)

    def trigger_on_event(self, lock):
        pass  # camera, no event to wait.
    # END MUST.
