import time

class Eeprom:

    def __init__(self,i2c):
        self.i2c = i2c


    def loadDataSheet(self,fileName):
        f = open(fileName,"r")
        data = f.read()
        f.close()
        buf = list(bytearray(data)) #convert string to list
        # write the size of the file on the memory address (for later use in read process)
        j = 0
        size = len(buf)
        self.i2c.bus.write_word_data(self.i2c.deviceAddress,j,size)
        time.sleep(0.004)
        j = j+2
        #write the file on memory
        print "file loading , please wait ......."
        for i in buf:
            if(j == 256):#write to the next block of memory
                j = 0
                self.i2c.setDeviceAddress(self.i2c.getDeviceAddress() + 1)
            self.i2c.write(j,i)
            time.sleep(0.004)
            j = j +1
        print "file loaded successfully"



    def readDataSheet(self,fileName):
        # get the size of the dataSheet file
        j = 0
        size = self.i2c.read(0,2) #read the first byte
        print "la taille est : ", size
        time.sleep(0.004)
        count = 0
        j =j +2
        buf = list()
        print "file reading , please wait ......."
        while (count < size):
            if(j == 256):
                j =0
                self.i2c.setDeviceAddress(self.i2c.getDeviceAddress() +1)
            buf.append(str(unichr(self.i2c.read(j,1))))
            time.sleep(0.004)
            j = j+1
            count = count + 1
            print count
        f = open(fileName,"w")
        data = ''.join(buf)
        f.write(data)
        f.close()
        print "read complete successfully"


    def eraseAll(self):
        blocks = [0x50, 0x51, 0x52, 0x53, 0x54, 0x55, 0x56, 0x57]
        print "erasing memory, please wait......."
        for i in blocks:
            self.i2c.setDeviceAddress(i)
            for j in range(0,256):
                self.i2c.write(j,0)
                time.sleep(0.004)
        print "memory successfully erased"
