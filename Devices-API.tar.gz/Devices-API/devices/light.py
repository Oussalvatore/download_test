class Light:
    def __init__(self,i2c):
        self.spi = i2c