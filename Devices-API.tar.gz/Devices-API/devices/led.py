import interfaces.boardGpio as Board
import interfaces.interfaceGPIO as interfaceGPIO


class Led:
    def __init__(self, which_board, physical_pin_number):
        pin = Board.BoardGpio(which_board=which_board, physical_pin_number=physical_pin_number)
        self.__gpio = interfaceGPIO.InterfaceGPIO(out=physical_pin_number)
        self.__last_state = 0

    def act(self):
        self.__last_state = (self.__last_state + 1) % 2
        self.__gpio.write(self.__last_state)
        return True

