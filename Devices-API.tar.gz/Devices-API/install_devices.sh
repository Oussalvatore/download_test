#!/usr/bin/env bash
# configure UART, SPI, RPi.GPIO fro example
apt-get -y install python-rpi.gpio
apt-get -y install python-serial
apt-get -y install build-essential
apt-get -y install python-dev
python /tmp/Devices-API/setup.py install >> /tmp/progress.txt