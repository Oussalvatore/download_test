# setup the main programme
from setuptools import setup, find_packages

setup(name='IoTaas-Devices-API',
      version='0.1',
      description='get IoT as a service from raspberry pi ',
      url='http://not-yet.com/',
      author='BEKKOUCHE OUSSSAMA & GOUGAM MOHAMED',
      author_email='IoTaas@gmail.com',
      license='MIT',
      packages=find_packages(),
      install_requires=['Adafruit_DHT'],
      dependency_links=['https://github.com/adafruit/Adafruit_Python_DHT/tarball/master#egg=Adafruit_DHT-1.3.2'],
      zip_safe=False)

print "installation done"
exit(0)