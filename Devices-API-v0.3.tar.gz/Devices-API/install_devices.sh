#!/usr/bin/env bash
# configure UART, SPI, RPi.GPIO fro example
apt-get -y install python-rpi.gpio
apt-get -y install python-serial


python setup.py install