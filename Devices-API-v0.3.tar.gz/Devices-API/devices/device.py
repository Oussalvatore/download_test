class Device:
    def __init__(self,interface):
        self.interface = interface

    def Sens(self):
        """TODO: implement Sens method on a child class"""
    def Act(self):
        """TODO: implement Act method on a child class"""