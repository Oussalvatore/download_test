import json

# Reading data back
with open('dataSheet.json', 'r') as f:
     data = json.load(f)

for k in data:
    for i in (data[k]):
        print "Type : ", i["type"],", Interface : ",(i["interface"])["type"],"==> bus ",(i["interface"])["bus"]," , Reference : ",i["reference"]
    print "********** fin ",k," *************"

